from mahjong.botzone.runner import main
main()
